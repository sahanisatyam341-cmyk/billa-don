# Billa Don 😈

Tera gunda AI dost.  
Grok jaisa smart + helpful, lekin full desi gali-galoch + attitude wala.

## Features
- Pure Hinglish mein baat karta hai
- Bahut gaali deta hai (natural way mein)
- Streamlit UI — browser mein open hota hai
- Groq / OpenRouter / Together AI support
- Temperature control (jitna zyada, utna jyada attitude)

## Setup (2 minute)

1. Clone karo ya zip extract karo
2. Terminal mein:
```bash
cd billa-don
pip install -r requirements.txt
```

3. Free API key lo:
- **Sabse recommended**: [Groq](https://console.groq.com) → bilkul free + bahut fast
- OpenRouter ya Together bhi chalega

4. `.env` file banao:
```bash
cp .env.example .env
```
Usme apna key daal do.

5. Run karo:
```bash
streamlit run app.py
```

Browser automatically open ho jayega.

## Tips
- Sidebar mein API key daal sakte ho (agar .env nahi banaya)
- Temperature 0.9–1.1 pe best attitude aata hai
- Chat clear karne ka button sidebar mein hai

## License
Kar le jo marzi. Billa Don free hai.  
Bas naam mat badal dena chutiye 🐱‍👤
