import streamlit as st
from openai import OpenAI
from billa_prompt import BILLA_SYSTEM_PROMPT
import os
from dotenv import load_dotenv

load_dotenv()

st.set_page_config(
    page_title="Billa Don 😈",
    page_icon="🐱",
    layout="centered"
)

st.title("Billa Don 😈")
st.caption("Tera gunda AI dost • Full gali-galoch mode")

# Sidebar for settings
with st.sidebar:
    st.header("Settings")
    api_key = st.text_input("API Key", type="password", value=os.getenv("GROQ_API_KEY", ""))
    base_url = st.selectbox(
        "Provider",
        options=[
            "https://api.groq.com/openai/v1",
            "https://openrouter.ai/api/v1",
            "https://api.together.xyz/v1",
        ],
        index=0
    )
    model = st.selectbox(
        "Model",
        options=[
            "llama-3.3-70b-versatile",
            "llama-3.1-8b-instant",
            "mixtral-8x7b-32768",
            "gemma2-9b-it",
            "meta-llama/llama-3.1-70b-instruct",  # for OpenRouter
            "meta-llama/Meta-Llama-3.1-8B-Instruct-Turbo",  # Together
        ],
        index=0
    )
    temperature = st.slider("Temperature (attitude)", 0.5, 1.3, 0.95, 0.05)

if not api_key:
    st.warning("Sidebar mein API Key daal pehle bhai. Free key le → https://console.groq.com")
    st.stop()

client = OpenAI(
    api_key=api_key,
    base_url=base_url
)

if "messages" not in st.session_state:
    st.session_state.messages = [
        {"role": "system", "content": BILLA_SYSTEM_PROMPT}
    ]

# Show chat history
for msg in st.session_state.messages[1:]:  # system message hide
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# Chat input
if prompt := st.chat_input("Billa se baat kar..."):
    st.session_state.messages.append({"role": "user", "content": prompt})
    
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        with st.spinner("Billa soch raha hai..."):
            try:
                response = client.chat.completions.create(
                    model=model,
                    messages=st.session_state.messages,
                    temperature=temperature,
                    max_tokens=1024,
                )
                reply = response.choices[0].message.content
                st.markdown(reply)
                st.session_state.messages.append({"role": "assistant", "content": reply})
            except Exception as e:
                st.error(f"Error aa gaya madarchod: {str(e)}")

# Clear chat button
if st.sidebar.button("Chat clear kar"):
    st.session_state.messages = [
        {"role": "system", "content": BILLA_SYSTEM_PROMPT}
    ]
    st.rerun()
